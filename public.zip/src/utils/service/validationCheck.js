export const isvalid = {
  Name: /^[A-Za-z][A-Za-z0-9_]{3,29}$/g,
  Email: /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g,
};
