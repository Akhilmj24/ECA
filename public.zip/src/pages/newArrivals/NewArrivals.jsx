import React from 'react'

export default function NewArrivals() {
  return (
    <div>NewArrivals</div>
  )
}
