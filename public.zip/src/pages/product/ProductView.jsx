import React from 'react'

export default function ProductView() {
  return (
    <div>ProductView</div>
  )
}
